package edu.gatech.cs1331.hw09;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw09DungeonLootManagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
